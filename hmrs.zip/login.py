import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as tb
import mysql.connector
from hashlib import sha256
from PIL import Image, ImageTk
import subprocess  # For running the hotel management script

# Database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Root123",
    database="hms"
)
cursor = db.cursor()

# Password hashing
def hash_password(password):
    return sha256(password.encode()).hexdigest()

# Login functionality
def login_user():
    username = username_entry.get()
    email = email_entry.get()
    password = password_entry.get()

    if not username or not email or not password:
        messagebox.showerror("Error", "All fields are required!")
        return

    hashed_password = hash_password(password)
    query = "SELECT * FROM users WHERE username = %s AND email = %s AND password = %s"
    cursor.execute(query, (username, email, hashed_password))
    result = cursor.fetchone()

    if result:
        messagebox.showinfo("Success", f"Welcome back, {username}!")
        login_window.destroy()

        # Open the hotel management system file
        subprocess.Popen(['python', 'hotelamanagement (1).py'])
    else:
        messagebox.showerror("Error", "Invalid credentials. Please try again!")

# Sign-up functionality
def signup_user():
    username = username_entry.get()
    email = email_entry.get()
    password = password_entry.get()

    if not username or not email or not password:
        messagebox.showerror("Error", "All fields are required!")
        return

    if len(password) < 6:
        messagebox.showerror("Error", "Password must be at least 6 characters long!")
        return

    hashed_password = hash_password(password)
    try:
        query = "INSERT INTO users (username, email, password) VALUES (%s, %s, %s)"
        cursor.execute(query, (username, email, hashed_password))
        db.commit()
        messagebox.showinfo("Success", "Account created successfully! Please log in.")
    except mysql.connector.IntegrityError as e:
        if "username" in str(e):
            messagebox.showerror("Error", "Username already exists!")
        elif "email" in str(e):
            messagebox.showerror("Error", "Email already exists!")

# Create login window
login_window = tb.Window(themename="darkly")
login_window.geometry("800x500")
login_window.title("Login Page")

# Add background image
bg_image_path =  "C:\\Users\\Akki\\OneDrive\\Desktop\\n1\\p.jpg"  # Path to the uploaded image
try:
    bg_image = Image.open(bg_image_path)

    # Resize the image to fit the window size dynamically
    def resize_bg(event):
        new_width = event.width
        new_height = event.height
        resized_bg_image = bg_image.resize((new_width, new_height), Image.Resampling.LANCZOS)
        bg_image_tk = ImageTk.PhotoImage(resized_bg_image)

        # Update the background label with the new image
        bg_label.config(image=bg_image_tk)
        bg_label.image = bg_image_tk  # Keep a reference to avoid garbage collection

    # Create a label to display the background image
    bg_label = tk.Label(login_window)
    bg_label.place(relwidth=1, relheight=1)
    bg_label.bind("<Configure>", resize_bg)  # Bind window resizing to resize the image
    resize_bg(login_window)  # Initial resize for the current window size

except Exception as e:
    print(f"Error loading background image: {e}")
    bg_label = tk.Label(login_window, text="Welcome", font=("Helvetica", 20), bg="gray")
    bg_label.place(relwidth=1, relheight=1)

# Center frame for login form
form_frame = tk.Frame(login_window, bg="white", bd=10, relief="groove")
form_frame.place(relx=0.3, rely=0.2, relwidth=0.4, relheight=0.6)

# Add form fields
tk.Label(form_frame, text="Login Page", font=("Helvetica", 18, "bold"), bg="white").pack(pady=10)

tk.Label(form_frame, text="Username:", font=("Helvetica", 12), bg="white").pack(pady=5, anchor="w", padx=20)
username_entry = tk.Entry(form_frame, font=("Helvetica", 12))
username_entry.pack(pady=5, padx=20, fill="x")

tk.Label(form_frame, text="Email:", font=("Helvetica", 12), bg="white").pack(pady=5, anchor="w", padx=20)
email_entry = tk.Entry(form_frame, font=("Helvetica", 12))
email_entry.pack(pady=5, padx=20, fill="x")

tk.Label(form_frame, text="Password:", font=("Helvetica", 12), bg="white").pack(pady=5, anchor="w", padx=20)
password_entry = tk.Entry(form_frame, font=("Helvetica", 12), show="*")
password_entry.pack(pady=5, padx=20, fill="x")

# Buttons
login_button = tb.Button(form_frame, text="Login", bootstyle="primary", command=login_user)
login_button.pack(pady=10, padx=20, side="left", expand=True)

signup_button = tb.Button(form_frame, text="Sign Up", bootstyle="secondary", command=signup_user)
signup_button.pack(pady=10, padx=20, side="right", expand=True)

# Run the application
login_window.mainloop()
