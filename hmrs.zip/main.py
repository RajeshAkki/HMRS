from tkinter import *
from PIL import Image, ImageTk
import mysql.connector
import os  # For launching another script

# Establish MySQL connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Root123",
    database="raj"
)
cursor = db.cursor()

# Designing window for registration
def register():
    global register_screen
    register_screen = Toplevel(main_screen)
    register_screen.title("Register")
    register_screen.geometry("300x250")

    global username
    global password
    global username_entry
    global password_entry
    username = StringVar()
    password = StringVar()

    Label(register_screen, text="Please enter details below", bg="blue").pack()
    Label(register_screen, text="").pack()
    Label(register_screen, text="Username * ").pack()
    username_entry = Entry(register_screen, textvariable=username)
    username_entry.pack()
    Label(register_screen, text="Password * ").pack()
    password_entry = Entry(register_screen, textvariable=password, show='*')
    password_entry.pack()
    Label(register_screen, text="").pack()
    Button(register_screen, text="Register", width=10, height=1, bg="green", fg="white", command=register_user).pack()

# Register user logic
def register_user():
    username_info = username.get()
    password_info = password.get()

    if username_info and password_info:
        try:
            cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username_info, password_info))
            db.commit()
            Label(register_screen, text="Registration Success", fg="green", font=("calibri", 11)).pack()
            username_entry.delete(0, END)
            password_entry.delete(0, END)
        except mysql.connector.Error as err:
            Label(register_screen, text=f"Error: {err}", fg="red", font=("calibri", 11)).pack()
    else:
        Label(register_screen, text="All fields are required", fg="red", font=("calibri", 11)).pack()

# Login window
def login():
    global login_screen
    login_screen = Toplevel(main_screen)
    login_screen.title("Login")
    login_screen.geometry("300x250")

    global username_verify
    global password_verify
    global username_login_entry
    global password_login_entry

    username_verify = StringVar()
    password_verify = StringVar()

    Label(login_screen, text="Username * ").pack()
    username_login_entry = Entry(login_screen, textvariable=username_verify)
    username_login_entry.pack()
    Label(login_screen, text="Password * ").pack()
    password_login_entry = Entry(login_screen, textvariable=password_verify, show='*')
    password_login_entry.pack()
    Label(login_screen, text="").pack()
    Button(login_screen, text="Login", width=10, height=1, bg="blue", fg="white", command=login_verify).pack()

# Login logic
def login_verify():
    username1 = username_verify.get()
    password1 = password_verify.get()

    cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username1, password1))
    result = cursor.fetchone()

    if result:
        login_success()
    else:
        login_failure()

def login_success():
    global login_success_screen
    login_success_screen = Toplevel(login_screen)
    login_success_screen.title("Success")
    login_success_screen.geometry("150x100")
    Label(login_success_screen, text="Login Success").pack()
    Button(login_success_screen, text="OK", command=launch_hms).pack()

def login_failure():
    global login_failure_screen
    login_failure_screen = Toplevel(login_screen)
    login_failure_screen.title("Failure")
    login_failure_screen.geometry("150x100")
    Label(login_failure_screen, text="Invalid Credentials").pack()
    Button(login_failure_screen, text="OK", command=login_failure_screen.destroy).pack()

# Launch HMS.py after successful login
def launch_hms():
    login_success_screen.destroy()
    login_screen.destroy()
    os.system("python hms.py")  # Replace with the correct path to your HMS script

# Main account screen with a Canva-style title
def main_account_screen():
    global main_screen
    main_screen = Tk()
    main_screen.geometry("500x400")
    main_screen.title("Account Login")

    # Adding background image
    bg_image = Image.open("C:\\Users\\Akki\\OneDrive\\Desktop\\n1\\raj.jpg")  # Path to your background image
    bg_image = bg_image.resize((500, 400), Image.Resampling.LANCZOS)
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label = Label(main_screen, image=bg_photo)
    bg_label.image = bg_photo  # Keep a reference to avoid garbage collection
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)

    # Adding logo
    logo_image = Image.open("C:\\Users\\Akki\\OneDrive\\Desktop\\n1\\logo.jpg")  # Path to your logo image
    logo_image = logo_image.resize((100, 100), Image.Resampling.LANCZOS)
    logo_photo = ImageTk.PhotoImage(logo_image)
    logo_label = Label(main_screen, image=logo_photo, bg="white")
    logo_label.image = logo_photo
    logo_label.pack(pady=10)

    # Canva-style title
    title_frame = Frame(main_screen, bg="blue", pady=10)
    title_frame.pack(fill=X)
    Label(title_frame, text="Welcome Back!!!", font=("Arial", 24, "bold"), bg="blue", fg="white").pack()

    # Login and Register buttons
    Label(main_screen, text="").pack()
    Button(main_screen, text="Login", height="2", width="30", bg="blue", fg="white", command=login).pack()
    Label(main_screen, text="").pack()
    Button(main_screen, text="Register", height="2", width="30", bg="green", fg="white", command=register).pack()

    main_screen.mainloop()

main_account_screen()
